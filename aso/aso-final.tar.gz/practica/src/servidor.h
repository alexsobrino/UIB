void servidor (int, int);
