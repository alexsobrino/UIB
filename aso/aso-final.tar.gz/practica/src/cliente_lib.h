int mi_read_cliente (char *, int, int, char *, int, int);
int mi_write_cliente (char *, int, int, char *, int, int);
int mi_create_cliente (char *, int, int);
int mi_stat_cliente (char *, int, int);
int mi_rm_cliente (char *, int, int);
int mi_dir_cliente (char *, char *, int, int);
