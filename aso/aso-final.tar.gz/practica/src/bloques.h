int montar_bloques (char *);
int desmontar_bloques ();
int leer_bloque (int, char *);
int escribir_bloque (int, char *);
