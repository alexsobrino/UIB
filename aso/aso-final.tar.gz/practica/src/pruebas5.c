#include "directorio.h"
int main (void) 
{
	printf("tama�o: %d\n",sizeof(entrada));
}
