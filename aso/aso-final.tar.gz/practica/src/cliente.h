void cliente (int, int);
