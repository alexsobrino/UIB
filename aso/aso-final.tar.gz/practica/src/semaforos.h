int crear_sem (int);
void eliminar_sem (int);
void esperar_sem (int, int, int);
void senalizar_sem (int, int);
void esperar_cero (int, int);
int inicializar_ls (void);
int inicializar_mutex (int);
void entrada_lectores (int);
void salida_lectores (int);
void entrada_escritores (int);
void salida_escritores (int);

