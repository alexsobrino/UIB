#include "../src/ficheros_basico.h"

int main (void)
{
	printf("Tama�o de inodo: %d\n",sizeof(inodo));
}

