int nuevo_sem2(int, int);
void esperar_sem2(int, int, int);
void senalizar_sem2(int, int);
void esperar_cero2(int, int);
void inicializar_le(void);
void entrada_lectores(void);
void salida_lectores(void);
void entrada_escritores(void);
void salida_escritores(void);

