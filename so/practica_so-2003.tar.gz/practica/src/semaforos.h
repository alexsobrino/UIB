int nuevo_sem(int, int );
void eliminar_sem(int);
int inicializar_sem(int, int);
void esperar_sem(int);
void senalizar_sem(int);
